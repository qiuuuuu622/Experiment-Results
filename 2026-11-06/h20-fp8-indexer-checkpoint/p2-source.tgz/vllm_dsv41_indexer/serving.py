# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Opt-in decode adapter. Candidate publication belongs to one forward context.

Unsupported layouts retain the upstream path. In particular, ragged verify,
CP, FP4 caches and nonstandard candidate geometry are not coerced into the FP8
ABI. This adapter does not partition index heads across TP ranks.
"""

import torch

from .workspace import CandidateState, CompactIndexer


def supported(*, q, cache, candidates, weights, rows, next_n, lengths,
              table, padded, use_pcp, dcp_size, use_fp4, topk, block_size,
              max_seq_len):
    return (
        q.is_cuda
        and torch.cuda.get_device_capability(q.device) == (9, 0)
        and not (padded or use_pcp or use_fp4)
        and dcp_size == 1
        and rows > 0
        and rows <= 16384  # At most 1 GiB of compact FP32 scores.
        and max_seq_len >= 262144
        and topk == 512
        and block_size == 8
        and candidates is not None
        and candidates.shape == (rows, 2048)
        and candidates.dtype == torch.int32
        and candidates.is_contiguous()
        and q.shape == (rows, 32, 128)
        and q.dtype == torch.float8_e4m3fn
        and q.is_contiguous()
        and weights.shape == (rows, 32)
        and weights.dtype == torch.float32
        and weights.is_contiguous()
        and cache.ndim == 4
        and cache.shape[1:] == (64, 1, 132)
        and cache.dtype == torch.uint8
        and cache.is_contiguous()
        and lengths.numel() == rows
        and lengths.dtype == torch.int32
        and lengths.is_contiguous()
        and table.ndim == 2
        and table.shape[0] * next_n == rows
        and table.dtype == torch.int32
        and table.is_contiguous()
    )


def _key(candidates, lengths, table, next_n):
    # Require the same metadata storage, not just coincidentally equal shapes.
    # The per-forward registry prevents cross-step reuse after request reorder.
    return (candidates.data_ptr(), tuple(candidates.shape), lengths.data_ptr(),
            tuple(lengths.shape), table.data_ptr(), tuple(table.shape), next_n)


def publish(context, candidates, lengths, table, next_n):
    """Run immediately after the native source writes unique candidate blocks."""
    registry = getattr(context, "_dsv41_compact_candidates", None)
    if registry is None:
        registry = {}
        context._dsv41_compact_candidates = registry
    state = CandidateState(candidates.shape[0], candidates.device)
    state.publish(candidates, lengths.reshape(-1), source_unique=True)
    registry[_key(candidates, lengths, table, next_n)] = state


def consume(context, candidates, lengths, table, next_n, q, weights, cache, out):
    """Return False unless a matching source published in this forward."""
    registry = getattr(context, "_dsv41_compact_candidates", {})
    state = registry.get(_key(candidates, lengths, table, next_n))
    if state is None:
        return False
    requests = torch.arange(table.shape[0], dtype=torch.int32, device=q.device)
    requests = requests.repeat_interleave(next_n)
    op = CompactIndexer(state, q, weights, cache, table, requests)
    out.copy_(op.forward())
    return True
