# SPDX-License-Identifier: Apache-2.0
"""Actual four-rank ownership correctness; --allow-single-rank is diagnostic only."""

import argparse
import json

import torch
import torch.distributed as dist

from .common import save
from .tp4_cases import (
    build_variants,
    canonical,
    digest,
    initialize,
    make_case,
    provenance,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--allow-single-rank", action="store_true")
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    world = initialize(args.allow_single_rank)
    cases = [
        dict(requests=1, verify=1, context=4096),
        dict(requests=1, verify=6, context=16384),
        dict(requests=5, verify=1, context=4096, ragged=True, reorder=True),
        dict(requests=5, verify=1, context=32768, ratio=2),
        dict(requests=3, verify=2, context=4096, workload="chain"),
        dict(requests=5, verify=1, context=4096, workload="full"),
        dict(requests=5, verify=1, context=4096, projection=True),
    ]
    if args.quick:
        cases = cases[:2] + cases[-1:]
    records = []
    for case in cases:
        fields, factory, spec, table = make_case(**case)
        variants = build_variants(fields, factory, input_modes=("replicated", "root"))
        original = {k: v.clone() for k, v in fields.items()}
        graphs = {}
        for name, variant in variants.items():
            for _ in range(3):
                variant.forward()
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                variant.forward()
            graphs[name] = graph
        for step in range(4):
            for k, value in fields.items():
                value.copy_(original[k])
            if step == 1:
                fields["lengths"][::3] = 0
                fields["lengths"][1::3] = 517
                if "blocks" in fields:
                    fields["blocks"][:, 1] = fields["blocks"][:, 0]
                    fields["blocks"][:, 2] = -1
            if step == 2:
                if "hidden" in fields:
                    fields["hidden"].zero_()
                else:
                    for k, value in fields.items():
                        if k.startswith("q"):
                            value.zero_()
            if step == 3:
                fields["requests"].copy_((original["requests"] + 1) % spec["requests"])
                fields["lengths"].sub_(13).clamp_min_(0)
                if "blocks" in fields:
                    fields["blocks"][:, ::2] = -1
            for execution in ("eager", "graph"):
                expected = None
                for name, variant in variants.items():
                    if execution == "graph":
                        graphs[name].replay()
                    else:
                        variant.forward()
                    actual = canonical(variant.output)
                    if expected is None:
                        expected = actual.clone()
                    assert torch.equal(actual, expected), (spec, step, execution, name)
                    for row, length in enumerate(fields["lengths"].tolist()):
                        for stage in actual[row]:
                            live = stage[stage >= 0]
                            assert live.numel() == live.unique().numel()
                            assert not live.numel() or int(live.max()) < length
                    record = dict(
                        case=spec,
                        step=step,
                        execution=execution,
                        variant=name,
                        sha256=digest(actual),
                        physical_table_sha256=digest(table),
                    )
                    if name != "replicated":
                        record["communication"] = variant.communication()
                    records.append(record)
        torch.cuda.synchronize()
        del variants, graphs, fields, factory
        torch.cuda.empty_cache()
        if dist.get_rank() == 0:
            print(json.dumps(dict(case=spec, status="passed")), flush=True)
    gathered = [None] * world
    dist.all_gather_object(gathered, records)
    for idx in range(len(records)):
        assert len({r[idx]["sha256"] for r in gathered}) == 1
        if world > 1:
            assert len({r[idx]["physical_table_sha256"] for r in gathered}) == world
    if dist.get_rank() == 0:
        save(
            args.output,
            dict(
                status="passed",
                physical_world=world,
                single_rank_diagnostic=world == 1,
                source_sha256=provenance(),
                checks_per_rank=len(records),
                ranks=gathered,
            ),
        )
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
